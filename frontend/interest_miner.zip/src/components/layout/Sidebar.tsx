import React, { useEffect, useState } from "react";
import {
  Home,
  Search,
  BarChart3,
  Download,
  Settings,
  Link as LinkIcon,
  User,
  Brain,
  History,
  Pickaxe,
} from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

import { openPricingModal } from "../../../store/features/pricingModalSlice";
import { resetSearchState } from "../../../store/features/facebookSlice";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { GiMiner } from "react-icons/gi";

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const location = useLocation();
  const dispatch = useAppDispatch();
  const router = useNavigate();
  const {
    data: userData,
    loading,
    error,
    updateSuccess,
  } = useAppSelector((state) => state.profile);

  // Theme state that listens to document changes
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Listen for theme changes
  useEffect(() => {
    const checkTheme = () => {
      const isDark = document.documentElement.classList.contains("dark");
      setIsDarkMode(isDark);
    };

    // Initial check
    checkTheme();

    // Create observer to watch for class changes
    const observer = new MutationObserver(checkTheme);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => observer.disconnect();
  }, []);

  const navigationItems = [
    {
      name: "Dashboard",
      icon: Home,
      path: "/dashboard",
      active: location.pathname === "/dashboard",
    },
    {
      name: "Miner Generator",
      icon: GiMiner,
      path: "/miner",
      active: location.pathname === "/miner",
    },
    {
      name: "Premium Generator",
      icon: Brain,
      path: "/permium-miner",
      active: location.pathname === "/permium-miner",
    },
    {
      name: "Campaign Analytics",
      icon: BarChart3,
      path: "/analytics",
      active: location.pathname === "/analytics",
      badge: "New",
    },
    {
      name: "Export Center",
      icon: Download,
      path: "/export",
      active: location.pathname === "/export",
    },
  ];

  const metaIntegration = [
    {
      name: "Connect Meta",
      icon: LinkIcon,
      path: "/meta-campaign",
      active: location.pathname === "/meta-campaign",
    },
  ];

  const accountItems = [
    {
      name: "Profile",
      icon: User,
      path: "/profile",
      active: location.pathname === "/profile",
    },
    {
      name: "Account Settings",
      icon: Settings,
      path: "/profile-update",
      active: location.pathname === "/profile-update",
    },
    {
      name: "Search History",
      icon: History,
      path: "/search-history",
      active: location.pathname === "/search-history",
    },
  ];

  return (
    <motion.div
      className={`fixed left-0 top-0 z-50 h-screen bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 flex flex-col`}
      initial={false}
      animate={{
        width: isOpen ? 288 : 64,
      }}
      transition={{
        type: "spring",
        stiffness: 400,
        damping: 30,
        duration: 0.15,
      }}>
      <div className="flex flex-col h-full overflow-hidden">
        {/* Header */}
        <div
          className={`flex items-center px-4 border-b border-gray-200 dark:border-gray-700 min-h-[64px] ${
            !isOpen && "justify-center"
          }`}>
          <motion.div
            className="relative w-9 h-9 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}>
            <Link to="/miner" onClick={() => dispatch(resetSearchState())}>
              <Pickaxe className="h-6 w-6 text-white" />
            </Link>
          </motion.div>

          <AnimatePresence mode="wait">
            {isOpen && (
              <motion.div
                className="ml-3 overflow-hidden"
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                transition={{ duration: 0.15, ease: "easeInOut" }}>
                <h2 className="text-gray-900 dark:text-white font-semibold text-lg whitespace-nowrap">
                  InterestMiner
                </h2>
                <p className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                  AI-Powered Marketing
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Navigation - Remove scrollbar */}
        <div
          className="flex-1 px-2 py-6"
          style={{
            overflow: "hidden",
            scrollbarWidth: "none", // Firefox
            msOverflowStyle: "none", // IE/Edge
          }}>
          <style>{`
            ::-webkit-scrollbar {
              display: none; /* Chrome/Safari */
            }
          `}</style>

          <nav className="space-y-6">
            {/* Main Navigation */}
            <div>
              <AnimatePresence>
                {isOpen && (
                  <motion.h3
                    className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-3 px-2"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.15 }}>
                    Navigation
                  </motion.h3>
                )}
              </AnimatePresence>

              <ul className="space-y-1">
                {navigationItems.map((item, index) => (
                  <li key={item.name}>
                    <Link
                      to={item.path}
                      className={`group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 ${
                        item.active
                          ? "bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 shadow-sm"
                          : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white"
                      } ${!isOpen && "justify-center"}`}
                      title={!isOpen ? item.name : ""}>
                      <motion.div
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}>
                        <item.icon
                          className={`h-5 w-5 flex-shrink-0 transition-colors ${
                            item.active
                              ? "text-blue-600 dark:text-blue-400"
                              : "text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300"
                          } ${isOpen && "mr-3"}`}
                        />
                      </motion.div>

                      <AnimatePresence>
                        {isOpen && (
                          <motion.div
                            className="flex items-center justify-between flex-1 min-w-0"
                            initial={{ opacity: 0, width: 0 }}
                            animate={{ opacity: 1, width: "100%" }}
                            exit={{ opacity: 0, width: 0 }}
                            transition={{ duration: 0.15 }}>
                            <span className="whitespace-nowrap">
                              {item.name}
                            </span>
                            {item.badge && (
                              <span className="ml-3 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500 text-white shadow-sm flex-shrink-0">
                                {item.badge}
                              </span>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Meta Integration */}
            <div>
              <AnimatePresence>
                {isOpen && (
                  <motion.h3
                    className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-3 px-2"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.15 }}>
                    Meta Integration
                  </motion.h3>
                )}
              </AnimatePresence>

              <ul className="space-y-1">
                {metaIntegration.map((item) => (
                  <li key={item.name}>
                    <Link
                      to={item.path}
                      className={`group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 ${
                        item.active
                          ? "bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900/30 dark:to-red-900/30 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-800"
                          : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white"
                      } ${!isOpen && "justify-center"}`}
                      title={!isOpen ? item.name : ""}>
                      <motion.div
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}>
                        <item.icon
                          className={`h-5 w-5 flex-shrink-0 transition-colors ${
                            item.active
                              ? "text-orange-600 dark:text-orange-400"
                              : "text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300"
                          } ${isOpen && "mr-3"}`}
                        />
                      </motion.div>

                      <AnimatePresence>
                        {isOpen && (
                          <motion.span
                            className="whitespace-nowrap"
                            initial={{ opacity: 0, width: 0 }}
                            animate={{ opacity: 1, width: "auto" }}
                            exit={{ opacity: 0, width: 0 }}
                            transition={{ duration: 0.15 }}>
                            {item.name}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </Link>
                  </li>
                ))}
              </ul>

              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    className="mt-2 px-3"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.15 }}>
                    <div className="flex items-center space-x-2">
                      <motion.div
                        className="w-2 h-2 bg-green-500 rounded-full"
                        animate={{
                          opacity: [0.5, 1, 0.5],
                          scale: [1, 1.2, 1],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut",
                        }}
                      />
                      <p className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                        Campaign sync: 2 hours ago
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Account */}
            <div>
              <AnimatePresence>
                {isOpen && (
                  <motion.h3
                    className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-3 px-2"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.15 }}>
                    Account
                  </motion.h3>
                )}
              </AnimatePresence>

              <ul className="space-y-1">
                {accountItems.map((item) => (
                  <li key={item.name}>
                    <Link
                      to={item.path}
                      className={`group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 ${
                        item.active
                          ? "bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/30 dark:to-pink-900/30 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 shadow-sm"
                          : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white"
                      } ${!isOpen && "justify-center"}`}
                      title={!isOpen ? item.name : ""}>
                      <motion.div
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}>
                        <item.icon
                          className={`h-5 w-5 flex-shrink-0 transition-colors ${
                            item.active
                              ? "text-purple-600 dark:text-purple-400"
                              : "text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300"
                          } ${isOpen && "mr-3"}`}
                        />
                      </motion.div>

                      <AnimatePresence>
                        {isOpen && (
                          <motion.span
                            className="whitespace-nowrap"
                            initial={{ opacity: 0, width: 0 }}
                            animate={{ opacity: 1, width: "auto" }}
                            exit={{ opacity: 0, width: 0 }}
                            transition={{ duration: 0.15 }}>
                            {item.name}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </nav>
        </div>

        {/* Footer - User Info */}
        <AnimatePresence>
          {isOpen && userData && (
            <motion.div
              className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.15 }}>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-medium text-sm">
                    {userData.email
                      ? userData.email.charAt(0).toUpperCase()
                      : "U"}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                    {userData.email?.split("@")[0] || "User"}
                  </p>
                  <div className="flex items-center space-x-1">
                    <div
                      className={`w-2 h-2 rounded-full flex-shrink-0 ${
                        userData.subscription_status === "active"
                          ? "bg-green-500"
                          : "bg-orange-500"
                      }`}
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                      {userData.subscription_status === "active"
                        ? "Premium"
                        : "Free Trial"}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default Sidebar;
