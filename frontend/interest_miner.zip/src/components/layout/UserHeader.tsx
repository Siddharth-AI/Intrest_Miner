"use client";

import { useState, useRef, useEffect } from "react";
import { GiMiner } from "react-icons/gi";
import {
  Pickaxe,
  Bell,
  User,
  Menu,
  LogOut,
  X,
  ChevronRight,
  Settings,
  History,
  Sun,
  Moon,
} from "lucide-react";
import NotificationModel from "../model/NotificationModel";
import ProfileModal from "@/components/model/ProfileModel";
import { Link, useNavigate } from "react-router-dom";
import PremiumMinerButton from "../ui/PremiumMinerButton";
import { motion } from "framer-motion";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { resetSearchState } from "../../../store/features/facebookSlice";
import { fetchProfileData } from "../../../store/features/profileSlice";
import { openPricingModal } from "../../../store/features/pricingModalSlice";
import { FaMoneyBillWave } from "react-icons/fa";

// Add props interface
interface UserHeaderProps {
  onMenuClick: () => void;
  sidebarOpen: boolean;
}

export default function UserHeader({
  onMenuClick,
  sidebarOpen,
}: UserHeaderProps) {
  const {
    data: userData,
    loading,
    error,
    updateSuccess,
  } = useAppSelector((state) => state.profile);

  console.log(userData, "userdata in header");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isNotificationsOpen, setIsNotificationsOpen] =
    useState<boolean>(false);
  const [showPricingModal, setShowPricingModal] = useState<boolean>(false);
  const [showProfileMenu, setShowProfileMenu] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);

  const router = useNavigate();
  const mobileMenuRef = useRef<HTMLDivElement | null>(null);
  const bellRef = useRef<HTMLButtonElement | null>(null);
  const menuButtonRef = useRef<HTMLButtonElement | null>(null);
  const profileButtonRef = useRef<HTMLButtonElement | null>(null);
  const dispatch = useAppDispatch();

  const handleLogout = (): void => {
    localStorage.clear();
    router("/");
  };

  // Dark mode toggle function
  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    if (newTheme) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  };

  // Initialize theme on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia(
      "(prefers-color-scheme: dark)"
    ).matches;

    if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
      setIsDarkMode(true);
      document.documentElement.classList.add("dark");
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove("dark");
    }
  }, []);

  useEffect(() => {
    if (!userData && !loading && !error) {
      dispatch(fetchProfileData());
    }
  }, [dispatch, userData, loading, error]);

  const handlePremiumMinerClick = () => {
    console.log("Premium Miner button clicked.");
    console.log("Current userData:", userData);
    console.log("Current loading state:", loading);
    console.log("Current error state:", error);
    if (userData && userData.subscription_status) {
      const status = userData.subscription_status;
      if (status !== "active" && status == null) {
        dispatch(openPricingModal());
      } else if (status === "active") {
        router("/permium-miner");
      } else {
        dispatch(openPricingModal());
      }
    } else {
      dispatch(openPricingModal());
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent): void => {
      if (
        mobileMenuRef.current &&
        !mobileMenuRef.current.contains(event.target as Node) &&
        menuButtonRef.current &&
        !menuButtonRef.current.contains(event.target as Node)
      ) {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobileMenuOpen]);

  return (
    <>
      {/* Fixed header that adjusts to sidebar width */}
      <div
        className="fixed top-0 z-40 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shadow-sm transition-all duration-300"
        style={{
          left: sidebarOpen ? "320px" : "64px",
          right: "0",
        }}>
        <nav className="h-[70px] px-4 py-3 flex items-center justify-between">
          {/* Left Section: Sidebar Toggle + Welcome Message */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Desktop Sidebar Toggle Button */}
            <motion.button
              onClick={onMenuClick}
              className="hidden lg:flex p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 transition-colors"
              aria-label="Toggle sidebar"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}>
              <Menu className="h-6 w-6" />
            </motion.button>
          </div>

          {/* Right Section: Main Navigation (Desktop) */}
          <div className="hidden md:flex items-center space-x-4 lg:space-x-6">
            {/* Theme Toggle Button */}
            <motion.button
              onClick={toggleTheme}
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
              aria-label="Toggle theme"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}>
              {isDarkMode ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </motion.button>

            {/* Notifications */}
            <div className="relative">
              <motion.button
                ref={bellRef}
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 relative"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                aria-label="Notifications">
                <Bell size={20} />
                {/* Notification Dot with Animation */}
                <motion.div
                  className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-red-500 rounded-full border-2 border-white dark:border-gray-900"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </motion.button>
            </div>

            {/* Profile */}
            <div className="relative">
              <motion.button
                className="flex items-center space-x-3 p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                onClick={() => setShowProfileMenu((prev) => !prev)}
                ref={profileButtonRef}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}>
                <div className="w-9 h-9 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center shadow-md">
                  <span className="text-white font-semibold text-sm">
                    {userData?.email
                      ? userData.email.charAt(0).toUpperCase()
                      : "U"}
                  </span>
                </div>
                <div className="hidden lg:block text-left">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {userData?.email?.split("@")[0] || "User"}
                  </p>
                  <div className="flex items-center space-x-1">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        userData?.subscription_status === "active"
                          ? "bg-green-500"
                          : "bg-orange-500"
                      }`}
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {userData?.subscription_status === "active"
                        ? "Premium"
                        : "Free Trial"}
                    </p>
                  </div>
                </div>
              </motion.button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-2">
            {/* Mobile Theme Toggle */}
            <motion.button
              onClick={toggleTheme}
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}>
              {isDarkMode ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </motion.button>

            {/* Mobile Menu Toggle */}
            <motion.button
              ref={menuButtonRef}
              onClick={() => setIsMobileMenuOpen((prev) => !prev)}
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Open menu"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}>
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </motion.button>
          </div>
        </nav>
      </div>

      {/* Enhanced Mobile Menu Panel */}
      {isMobileMenuOpen && (
        <motion.div
          className="fixed inset-0 z-[9999] bg-white dark:bg-gray-900 md:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}>
          <motion.div
            ref={mobileMenuRef}
            className="fixed inset-0 bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 overflow-y-auto"
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}>
            {/* Mobile Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-3">
                <motion.div
                  className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-full p-3 shadow-lg"
                  whileHover={{ scale: 1.05 }}>
                  <Pickaxe className="h-7 w-7 text-white" />
                </motion.div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    InterestMiner
                  </h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Menu
                  </p>
                </div>
              </div>
              <motion.button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-3 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 transition-colors"
                aria-label="Close menu"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}>
                <X size={28} />
              </motion.button>
            </div>

            {/* Mobile Menu Content */}
            <div className="flex-1 p-6">
              <div className="space-y-6">
                {/* Main Actions */}
                <motion.div
                  className="space-y-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.2 }}>
                  <Link
                    to="/miner"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      dispatch(resetSearchState());
                    }}
                    className="flex items-center justify-center gap-3 text-white bg-gradient-to-r from-blue-600 to-blue-700 dark:from-blue-500 dark:to-blue-600 hover:from-blue-700 hover:to-blue-800 dark:hover:from-blue-600 dark:hover:to-blue-700 p-4 rounded-2xl transition-all duration-200 shadow-lg w-full">
                    <GiMiner size={24} />
                    <span className="text-lg font-semibold">Start Mining</span>
                  </Link>
                </motion.div>

                {/* Menu Items */}
                <motion.div
                  className="space-y-3"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.3 }}>
                  {[
                    { to: "/profile", icon: User, label: "Profile" },
                    {
                      to: "/profile-update",
                      icon: Settings,
                      label: "Account Settings",
                    },
                    {
                      to: "/search-history",
                      icon: History,
                      label: "Search History",
                    },
                    {
                      to: "/billing-history",
                      icon: FaMoneyBillWave,
                      label: "Billing History",
                    },
                  ].map((item, index) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="flex items-center justify-between text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800 p-4 rounded-2xl transition-all duration-200 border border-gray-200 dark:border-gray-700">
                      <div className="flex items-center gap-3">
                        <div className="bg-blue-100 dark:bg-blue-900/50 p-2 rounded-lg">
                          <item.icon
                            size={20}
                            className="text-blue-600 dark:text-blue-400"
                          />
                        </div>
                        <span className="text-base font-medium">
                          {item.label}
                        </span>
                      </div>
                      <ChevronRight size={20} />
                    </Link>
                  ))}
                </motion.div>
              </div>
            </div>

            {/* Mobile Footer */}
            <div className="p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
              <motion.button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  handleLogout();
                }}
                className="flex bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 items-center justify-center gap-3 text-white p-4 rounded-2xl transition-all duration-200 w-full shadow-lg">
                <LogOut size={20} />
                <span className="text-base font-medium">Logout</span>
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Profile Modal */}
      {showProfileMenu && (
        <ProfileModal
          onClose={() => setShowProfileMenu(false)}
          isOpen={showProfileMenu}
          triggerRef={profileButtonRef}
        />
      )}

      {/* Notification Dropdown */}
      <NotificationModel
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        triggerRef={bellRef}
      />
    </>
  );
}
