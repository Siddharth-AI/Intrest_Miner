import { Outlet } from "react-router-dom";
import UserHeader from "./UserHeader";
import { Footer } from "./Footer";
import Sidebar from "./Sidebar";
import { useState } from "react";

export default function AuthLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar - Fixed, full height */}
      <Sidebar isOpen={sidebarOpen} onToggle={toggleSidebar} />

      <div className="app-scale-wrapper">
        {/* Main content area that adjusts to sidebar */}
        <div
          className={`transition-all duration-300 ${
            sidebarOpen ? "ml-80" : "ml-16"
          }`}>
          {/* Header - Adjusts width based on sidebar */}
          <UserHeader onMenuClick={toggleSidebar} sidebarOpen={sidebarOpen} />

          {/* Main content - Scrollable with proper top padding */}
          <main className="pt-[70px]">
            <Outlet />
          </main>

          {/* Footer */}
          <Footer />
        </div>
      </div>
    </div>
  );
}
