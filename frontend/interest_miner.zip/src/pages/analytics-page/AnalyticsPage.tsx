import React from "react";

const AnalyticsPage = () => {
  return <div>start</div>;
};

export default AnalyticsPage;
